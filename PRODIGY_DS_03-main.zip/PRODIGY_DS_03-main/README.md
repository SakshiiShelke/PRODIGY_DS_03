# PRODIGY_DS_03
* Task 3: Building a Decision Tree Classifier for Customer Purchase Prediction.
* Objective: To create a decision tree classifier that can predict whether a customer will purchase a product or service based on their demographic and behavioral data using the UCI Machine Learning Repository's Bank dataset.
